$(document).ready(function(){
 console.log('hola puto mundo, desde miJs')
});

//jquerys 
//=============== parallax
$(document).ready(function(){
    $('.parallax').parallax();
  }); 